document.querySelector(".submitbutton2") .textContent = "Thank You!";

//This script file shows "Thank You!" after the submit button is pressed